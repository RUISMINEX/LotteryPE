Lotto Tickets
#Inspired from the hypixel Crates
#100% Coded originally
#Read License
#Noteblock:Lotto Block
#Blaze Powder: Lotto Ticket
#Players obtain lotto tickets by killing other players
#Everything can be changed but only in the code
#Copyright⊙ TheCGaming
